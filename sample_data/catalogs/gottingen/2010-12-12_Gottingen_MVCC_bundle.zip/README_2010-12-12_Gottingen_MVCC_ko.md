# 2010-12-12 Göttingen Best-of · MVCC/CORSET 검증

## 범위와 보존 원칙

이번 자료는 기존 `outputs/`에 추가했다. SEEDS·CACTus와 이벤트 매칭이나 병합을 수행하지 않았다. Göttingen은 선택적으로 수집한 수동 보조 참조이며, 완전한 이벤트 탐지 정답 목록으로 사용하지 않는다.

첨부 원본 8개와 붙여넣은 요청문을 `raw_2010-12-12_Gottingen_MVCC/`에 바이트 그대로 복사했다. EPS·PNG를 변환하거나 그림에서 수치를 재추정하지 않았다. 원래 Downloads 파일도 보존했다. 공식 Best-of HTML, MVCC 월별 HTML 및 JSON도 같은 폴더에 보존했다. `2010-12-12_Gottingen_MVCC_source_manifest.csv`의 경로·크기·SHA-256으로 각 파일을 확인할 수 있다.

CSV는 기존과 같은 UTF-8(무 BOM), 쉼표 구분, 단일 헤더, LF 줄바꿈이다. 분석 열의 빈 셀은 null이다. `-999`, `None`, `NULL`, `*`는 분석 열에서 null로 처리하고 `*_raw` 열 또는 원본 필드·스냅샷에 원래 표기를 남겼다. 숫자는 반올림·재적합·단위 변환 없이 원문 정밀도를 유지했다. 원문 공백은 MVCC `*_raw`와 보존 원본에서 확인할 수 있다.

시간은 UTC ISO 8601 `timestamp_utc`/`first_appearance_utc`와 원래 표기를 함께 보존했다. `.corset.ht`의 말미 점(`...05:24:00.`)은 소수부 숫자가 없으므로 분석 시각에서만 점을 제거했다. 다른 정밀도의 시간을 서로 보정하지 않았다. UTC는 이번 작업 지시에 따른 시간 기준이며 모든 첨부 파일 자체가 시간대를 명시한 것은 아니다.

## 주요 카탈로그

| CSV | 행 수 | 의미 |
| --- | ---: | --- |
| `2010-12-12_Gottingen_BestOf.csv` | 2 | 566a와 566b 원시 레코드 |
| `2010-12-12_MVCC_all_observations.csv` | 10 | COR2-A 5개, COR2-B 5개 관측 |
| `2010-12-12_MVCC_COR2A_events.csv` | 5 | 위 표에서 A만 선택 |

### Göttingen Best-of

공식 조회의 566a 17개 필드가 수동 전사 값과 전부 일치했다. 566b는 `no`, `date` 외의 15개 필드가 실제로 모두 `*`임을 확인했다. 566b는 `record_status=placeholder_not_separate_confirmed_CME`로 보존했으며 별도의 확정 CME로 세지 않는다. `no`의 a/b 접미사는 우주선 구분으로 해석하지 않았다.

- `no`, `date`: 원래 내부 번호와 탐지 날짜. `stable_event_id=GOTTINGEN_BESTOF_<no>`.
- `time_a`, `time_b`: COR2-A/B 첫 출현 시각. `PA_a`, `PA_b`, `SOHO_PA`의 `45/135`, `225/315`, `21/93`은 문자열 그대로 보존했다. 슬래시의 세부 의미는 확정하지 않았다.
- `SOHOdate`, `SOHOtime`: SOHO LASCO 카탈로그의 날짜·시각.
- `CMEspeed`: SOHO LASCO의 1차 선형 CME 속도(km/s). COR2-A 속도로 사용하면 안 된다.
- `clong_a`, `clong_b`: 우주선의 Carrington 경도. `hlong_a`, `hlong_b`: HEEQ 경도. `angle_e-a`, `angle_b-e`, `angle_b-a`: 우주선과 태양–지구 선 또는 두 우주선 사이의 분리각. 단위는 공식 표의 deg를 따른다. 공식 설명의 `clong_b` 문구가 spacecraft A로 반복된 점은 원문 표기의 오기로 보이며, 임의로 새로운 물리량으로 변경하지 않았다.
- 원본 이름의 열은 원래 표시값을 보존하고, `*_analysis`는 결측 표식을 null로 변환한 대응 열이다.

공식 표의 `time_b` 헤더에는 `[deg]`가 잘못 표시되지만, 범례와 실제 `hh:mm:ss` 형식을 따라 시각으로 보존했다.

### MVCC 관측 카탈로그

공식 JSON에서 2010-12-12인 행만 선택했다. 사용자가 제공한 10개 ID·분류·첫 출현 시각과 첫 쌍의 수치가 모두 일치했다. 각 쌍의 `cross_event_id`가 상호 대응하는지도 확인했다.

- `stable_event_id=MVCC_<event_id>`이며 `event_id`는 `c` 등의 접미사를 포함한 원래 ID다. `spacecraft`는 A/B, `event_type`은 `FP`, `F`, `OP` 원문 코드다.
- `cross_event_id`, `pair_id`는 공식 카탈로그 내부 A/B 관계만 표현한다. `detail_event_id`는 공식 사이트가 파일 링크를 만들 때 c/m 접미사를 제거하는 규칙을 따른다. 예: `1508.6938_0Ac` → `1508.6938_0A`.
- 공식 범례는 `F=Flux Rope`, `O=Other`, `P=Preceding CME`를 설명한다. 복합 코드 FP/OP의 결합 규칙을 임의로 풀어 쓰지 않았다. ID 끝의 `c`는 CORSET, `m`은 수동 측정, 접미사 없음은 측정 없음으로 명시되어 있다.
- `sepAngle`: 공식 범례가 우주선 분리각(deg)으로 정의한다. 실제 A=85, B=87을 그대로 보존했으며 합산·재계산하지 않았다.
- `CPA`, `width`: 태양 북쪽 기준 반시계 방향 중심 위치각과 각폭(deg).
- `Vrad`, `Vexp`: 공식 표시 단위 km/s. `alpha_rad`, `alpha_exp`: 공식 페이지는 km/s²로 표시한다. 수치는 원문(-16, -19, -11, -116)을 유지했다. `.ht`에는 가속도 단위가 없어 웹 표기와의 물리적 단위 일관성은 미해결 상태이며 임의로 m/s²로 변경하거나 1,000배 환산하지 않았다.
- `Mproj`, `Mdeproj`: 투영·비투영 질량(10^15 g). `latitude`, `longitude`: 위도와 Stonyhurst 경도(deg).
- `notes`: OVR/HAL/faint/PRM 등의 원문 코멘트. 공식 범례에서 OVR는 부분 중첩, HAL은 halo, faint는 약한 이벤트, PRM은 prominence 물질을 뜻한다.
- `database_id`, `eventPrefix`, `dataPath`, `txtFile`, `pngFile`: 공식 JSON의 식별·링크 관련 필드를 보존했다. 모든 원래 필드에는 `*_raw` 대응 열이 있다. `missing_value_provenance`는 결측으로 변환한 필드와 원래 표기의 JSON이다.

측정값이 없는 나머지 8개 관측도 삭제하지 않았다. 이들의 운동학 값은 `-999`, 질량·좌표·질량 파일 링크는 `None`이다. `sepAngle`과 일부 notes는 실제 값이 있으므로 유지했다. B `1508.7250_1B`의 notes `NULL`만 null로 변환했다.

## 상세 측정 CSV

공통 식별 열은 `spacecraft`, `catalog_event_id`, `detail_event_id`, `pair_id`다. 모든 측정은 원래 우주선으로 식별되며, A/B 시계열 파일은 분리했다. `source_filename`, `source_line`(1부터 시작), `source_section`(있는 경우), `source_url`, `provenance`가 원문 위치와 SHA-256을 제공한다. 로컬 상세 파일의 공식 URL은 source manifest에 기록했다. URL은 공식 페이지 링크 생성 규칙에서 얻었으며 온라인 파일과 첨부 파일의 바이트 동일성까지 검증한 것은 아니다.

아래의 `COR2A/B`는 각각 독립 파일이 있다는 뜻이다.

| CSV 이름 (`2010-12-12_MVCC_` 뒤) | A / B 행 수 | 열과 단위 |
| --- | ---: | --- |
| `CORSET_projected_mass_COR2A/B.csv` | 22 / 23 | 투영 높이 `projected_height_Rsun`, 질량 `projected_mass_1e15g`, `pixel_count` |
| `CORSET_morphology_COR2A/B.csv` | 22 / 23 | CoM·태양 중심 x/y(pix), CoM 반경(pix와 Rsun 별도), 프레임 CPA·각폭(deg), COR 높이(Rsun) |
| `CORSET_mass_only_deprojection_COR2A/B.csv` | 21 / 21 | Mass Only 방법의 depM, SatLon, depLon, depLat, depHt, projM, projH, CPA |
| `CORSET_mass_lat_height_deprojection_COR2A/B.csv` | 21 / 21 | Mass+Lat+Height 방법의 동일 이름 필드, 다른 계산 방법으로 독립 보존 |
| `GCS_mass_timeseries_COR2A/B.csv` | 22 / 23 | AFFECTSgcs 모델의 CORSET·GCS·GCS outer-only 질량(10^15 g) 및 픽셀 수, CORSET 높이(Rsun) |
| `CORSET_height_time_COR2A.csv` | 1,552 | 22개 시각의 각도별 leading-edge 높이, TEL, FC, COL, ROW, FEAT_CODE=LE |
| `CORSET_headers_COR2A.csv` | 29 | 모든 .ht 헤더, 결측과 중복 WDATA 행까지 보존 |
| `CORSET_fit_parameters_COR2A.csv` | 3 | 선형 속도 202.00, 2차 속도 266.00, 2차 가속도 -16.25를 분리 |
| `CORSET_tracking_metadata_COR2A.csv` | 28 | 배경 이미지 1개, 사용 이미지 22개, 추적 설정 5개 |
| `CORSET_profile_summaries.csv` | 총 4 | 우주선별 원문 maximum-mass/end 요약과 요약 시각 |
| `GCS_reconstructions.csv` | 총 1 | AFFECTSgcs lat/lon/tilt/AW(deg), kappa, ht(Rsun), v(km/s), 적합 시각 |
| `GCS_fit_mass_comparison.csv` | 총 2 | 해당 적합 시각의 A/B별 CORSET·GCS·outer-only 질량과 픽셀 수 |
| `Balmaceda_deprojection.csv` | 총 1 | 공동 방법 결과의 Lat, Lon, MassA, MassB 원문 수치 |

각도별 .ht 파일은 높이와 날짜 사이에 공백이 없으므로 고정 형식으로 파싱했다. 측정 ID는 원래 이벤트 ID와 원문 행 번호에서 안정적으로 생성했다. 원문에는 높이·ANGLE·COL/ROW·적합 속도·가속도의 단위가 명시되어 있지 않다. 따라서 이 CSV들의 `*_unit`은 `not_explicit_in_ht_file`로 두었다. 높이=Rsun, 각도=deg, 좌표=pix, 속도=km/s는 다른 프로파일·카탈로그와 일관적인 후보 해석이지만 이 파일 자체에서 명시된 단위는 아니다. 높이 행을 단순히 프레임 개수로 세면 안 된다. B의 `.corset.ht` 원문은 첨부되지 않았으므로 B 각도별 높이 측정 파일은 만들지 않았다.

deprojection 표의 `depM/projM`=질량, `depHt/projH`=높이, `SatLon/depLon/depLat/CPA`=위성 경도·비투영 경도·위도·위치각이다. 주변 프로파일의 질량(10^15 g), 높이(Rsun), 각도(deg) 문맥과 일치하지만 해당 deprojection 헤더에 단위가 반복 명시되지는 않았다. 경도 좌표계를 자동 통일하거나 서로 다른 방법의 수치를 같은 물리량으로 병합하지 않았다. Balmaceda 요약 구역도 단위·시각을 명시하지 않으므로 추정 단위를 부여하지 않았다.

GCS의 `AW`를 다른 표의 전체 각폭과 동일하다고 가정하지 않았다. GCS v의 `None`은 null이며 `velocity_raw=None`으로 원래 표기를 기록했다. CORSET/GCS 질량 비교 표와 시간 프로파일은 서로 다른 원문 구역이므로 각각 보존했다.

## 검증 결과와 남은 차이

- Best-of 2개 원시 레코드, MVCC A/B 5개씩 및 내부 상호 대응 5쌍 확인. source-to-CSV 필드·정밀도·결측 변환 검증 통과.
- 프로파일 헤더의 STA=22, STB=23이 투영 질량·형태·GCS 시계열의 실제 행 수와 일치한다. A .info의 22개 사용 이미지 및 .ht의 22개 고유 시각도 일치한다.
- 각 deprojection 방법은 양 우주선이 함께 있는 `05:39:00`–`12:24:00` 구간 21행이다. A 첫 프레임과 B 끝 2프레임을 결측 관측으로 새로 생성하지 않았다.
- B 카탈로그 첫 출현 `05:39:51`과 상세 프로파일의 첫 시각 `05:39:00`은 51초 차이다. 각각의 원래 시각을 보존했다. 상세 파일명의 `053900`을 A의 첫 출현 `05:24:00`으로 대체하지 않았다.
- A maximum-mass 요약은 08:24의 3.03을 선택하지만 07:39에도 같은 값이 있다. B도 07:39·07:54에 1.85가 있으며 원문 요약은 07:54를 선택한다. 동률을 새 규칙으로 덮어쓰지 않았다.
- A 08:24의 요약 CPA/각폭은 107/81인 반면 프레임 형태 표는 104.50/91.00이다. 이벤트 요약과 프레임 값을 서로 교체하지 않았다.
- A 카탈로그 Mproj=3.03과 Mdeproj=5.15는 같은 프레임의 투영·비투영 질량 한 쌍으로 간주할 수 없다. 상세 Mass+Lat+Height 표의 5.15는 07:54(projM=2.95)에 해당한다. 카탈로그 요약과 시계열을 별개로 유지했다.
- B 08:54 투영 시계열 높이 9.75와 deprojection 표의 projH=9.74 차이를 그대로 보존했다.
- GCS B 시계열 앞의 `Number of CORSET/GCS pairs in STA: 1`은 STA로 잘못 반복되어 있다. 실제 데이터 구역 제목 `Time Series in STB`를 기준으로 B에 분류했다.
- 적합 시각 09:24의 CORSET/GCS 비교 표 CORSET 질량(A=8.64, B=3.11)은 기본 투영 질량(A=2.63, B=1.47)과 다르다. 정의가 같은 것으로 가정하지 않았으며 비교 표와 시계열을 구분했다.
- 공식 가속도 단위 표기와 .ht 값의 물리적 해석은 추가 확인이 필요하다. 음의 Vexp=-1932도 원문 값으로 보존했다.

`2010-12-12_Gottingen_MVCC_validation.json`에 파일별 행 수와 검증 결과를 저장했다. 기존 파이프라인·AGENTS.md·SEEDS·CACTus CSV의 해시는 추출 전후 동일했다.

## 출처

- Best-of 원본 표: https://www.affects-fp7.eu/cme-database/bestofcmes.php?startDt1=20101212&endDt1=20101212&flagChk1=false&cmeSpeed1=0
- Göttingen 범례: https://www.affects-fp7.eu/cme-database/database.php.html
- MVCC 월별 페이지·범례: https://solar.jhuapl.edu/Data-Products/COR-CME-Catalog.php?yearMonth=2010-12
- MVCC 데이터 조회: `POST https://solar.jhuapl.edu/Data-Products/dataProcessing.php`, 요청 값 `yearMonth=2010-12`.
- 원래 상세 파일 URL과 로컬 경로는 source manifest 참조. 공식 조회일: 2026-10-20.

MVCC의 공식 출처 표기: The STEREO/SECCHI/COR2 CME catalog is generated and maintained at JHUAPL, in collaboration with the NRL and GSFC, and is supported by NASA.
